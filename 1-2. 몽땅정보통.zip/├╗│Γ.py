import requests
from bs4 import BeautifulSoup  
import pandas as pd
headers = {
    'Accept': 'text/html, */*; q=0.01',
    'Accept-Language': 'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7',
    'Connection': 'keep-alive',
    # Requests sorts cookies= alphabetically
    # 'Cookie': 'WMONID=P39Lr8bNFHw; YOUTHID=sfFS1qKPGijNZ11Am41xEJ6dDmymZktcKTX7JTHOZOj1jrLS73iaCCDjpvj7UWSa.amV1c19kb21haW4veW91dGgxMQ==',
    'Referer': 'https://youth.seoul.go.kr/site/main/customSupp/list',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-origin',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.5112.87 Whale/3.16.138.22 Safari/537.36',
    'X-Requested-With': 'XMLHttpRequest',
    'sec-ch-ua': '"Whale";v="3", " Not;A Brand";v="99", "Chromium";v="104"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
}

get_df = pd.DataFrame(columns=['정책명','정책유형','연령','신청절차','운영기관'])


for i in range(12):
    params = {
        'cp': i,
        'pageSize': '5',
        'polyBizSecd1': 'CT',
        # 'polyBizSecd1': 'GU',
        'csYear': '2022',
        # '_': '1660828629597',
    }

    r = requests.get('https://youth.seoul.go.kr/site/main/customSupp/cityList', params=params, headers=headers)
    # r = requests.get('https://youth.seoul.go.kr/site/main/customSupp/guList', params=params, headers=headers)

    r = BeautifulSoup(r.text, "lxml")
    bizId_list = r.select('ul.service-policy1 li a')
    # print(len(bizId_list))

    # if len(bizId_list) <5:
    #     print(123)
    print(bizId_list)
    for i in bizId_list:
        bizid = i['data-bizid']
        r = requests.get(f'https://youth.seoul.go.kr/site/main/customSupp/popView?bizId={bizid}', headers=headers)
        r = BeautifulSoup(r.text, "lxml")
        print(r.select_one('div.service-title1').text.strip())
        y = len(get_df)
        get_df.loc[y,"정책명"] = r.select_one('div.service-title1').text.strip()
        get_df.loc[y,"정책유형"] = r.select_one('div.W1280.service-cont1 > div:nth-child(2) > table > tbody > tr:nth-child(1) > td').text.strip()
        get_df.loc[y,"연령"] = r.select_one('div.W1280.service-cont1 > div:nth-child(4) > table > tbody > tr:nth-child(1) > td').text.strip()
        get_df.loc[y,"신청절차"] = r.select_one('div.W1280.service-cont1 > div:nth-child(6) > table > tbody > tr:nth-child(1) > td').text.strip()
        get_df.loc[y,"운영기관"] = r.select_one('div.W1280.service-cont1 > div:nth-child(8) > table > tbody > tr:nth-child(2) > td').text.strip()

get_df.to_excel(f"seoul.xlsx",encoding="utf-8-sig",index=False)
# service-policy1